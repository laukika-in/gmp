<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Optional: Clean up options, usermeta, etc.
// Example:
//delete_option('gmp_settings');

// Delete user_meta and other custom data here if needed.
