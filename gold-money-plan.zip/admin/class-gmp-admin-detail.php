<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class GMP_Admin_Detail {

    public static function render_page() {
        include GMP_PLUGIN_DIR . 'views/admin-cycle-detail.php';
    }
}
