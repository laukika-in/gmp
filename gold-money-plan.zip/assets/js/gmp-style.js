// GMP Frontend JS
jQuery(function($) {
    console.log('GMP frontend script loaded');
});
