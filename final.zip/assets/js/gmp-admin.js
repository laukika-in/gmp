// GMP Admin JS
jQuery(function($) {
    console.log('GMP admin script loaded');
});
